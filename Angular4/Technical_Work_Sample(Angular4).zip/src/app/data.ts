export class Data{
    Price: JSON;
    SMA: JSON;
    EMA: JSON;
    STOCH: JSON;
    RSI: JSON;
    ADX: JSON;
    CCI: JSON;
    BBANDS: JSON;
    MACD: JSON;
}