export class Option {
    Symbol: string;
    Name: string;
    Exchange: string;
  }